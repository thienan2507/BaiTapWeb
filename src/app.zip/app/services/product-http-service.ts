import { HttpClient } from '@angular/common/http';
import { Service } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../classes/IProduct';

@Service()
export class ProductHttpService {
    private _url:string="/dataset/products.json"
    constructor(private _http:HttpClient){}
    getProductList():Observable<Product[]>
    {
        return this._http.get<Product[]>(this._url);
    }
}
